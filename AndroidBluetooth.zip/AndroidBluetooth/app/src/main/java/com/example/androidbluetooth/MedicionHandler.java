package com.example.androidbluetooth;
import android.util.Log;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MedicionHandler {

    private static final String url = "http://192.168.1.47/pbiometria/src/api/mediciones/";

    private RequestQueue requestQueue;

    public MedicionHandler(RequestQueue requestQueue) {
        this.requestQueue = requestQueue;
    }

    public void postMediciones(final String ppm1, final String temp1) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("TEST", "FUNCIONA");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("TEST", String.valueOf(error));
                Log.d("TEST", "NO FUNCIONA");
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("temperatura", temp1);
                params.put("ppmO3", ppm1);
                return params;
            }
        };
        requestQueue.add(stringRequest);
    }
}

